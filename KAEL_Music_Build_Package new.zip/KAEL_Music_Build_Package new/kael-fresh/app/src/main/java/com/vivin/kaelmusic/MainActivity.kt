package com.vivin.kaelmusic

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

private data class Song(val id: Long, val title: String, val artist: String, val album: String, val uri: Uri)

class MainActivity : Activity() {
    private val songs = mutableListOf<Song>()
    private var visibleSongs = listOf<Song>()
    private var player: MediaPlayer? = null
    private var currentIndex = -1
    private lateinit var list: ListView
    private lateinit var titleNow: TextView
    private lateinit var artistNow: TextView
    private lateinit var playButton: Button
    private lateinit var countText: TextView
    private lateinit var search: EditText
    private var isPlaying = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        if (hasAudioPermission()) loadSongs() else requestPermissions(arrayOf(audioPermission()), 101)
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(0xFF111111.toInt())
        }
        val brand = TextView(this).apply {
            text = "KAEL  ♪"
            textSize = 29f
            setTextColor(0xFFFF8A35.toInt())
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        }
        root.addView(brand)
        root.addView(TextView(this).apply {
            text = "Your music, your way"
            textSize = 13f
            setTextColor(0xFFAAAAAA.toInt())
            setPadding(0, 0, 0, dp(14))
        })
        search = EditText(this).apply {
            hint = "Search songs or artists"
            setSingleLine(true)
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF888888.toInt())
            setPadding(dp(12), dp(5), dp(12), dp(5))
            setBackgroundColor(0xFF252525.toInt())
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        countText = TextView(this).apply {
            text = "YOUR SONGS"
            textSize = 12f
            setTextColor(0xFFFF8A35.toInt())
            letterSpacing = 0.12f
            setPadding(0, dp(15), 0, dp(8))
        }
        root.addView(countText)
        list = ListView(this).apply {
            divider = null
            dividerHeight = 0
            cacheColorHint = 0xFF111111.toInt()
            setBackgroundColor(0xFF111111.toInt())
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        val nowCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            setBackgroundColor(0xFF252525.toInt())
        }
        titleNow = TextView(this).apply {
            text = "Choose a song"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        artistNow = TextView(this).apply {
            text = "KAEL Music · Vivin"
            textSize = 13f
            setTextColor(0xFFAAAAAA.toInt())
            maxLines = 1
        }
        nowCard.addView(titleNow)
        nowCard.addView(artistNow)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val previous = controlButton("|◀") { playAt((currentIndex - 1).coerceAtLeast(0)) }
        playButton = controlButton("▶") { togglePlayback() }
        val next = controlButton("▶|") { if (visibleSongs.isNotEmpty()) playAt(((currentIndex + 1).coerceAtLeast(0)) % visibleSongs.size) }
        controls.addView(previous, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(playButton, LinearLayout.LayoutParams(0, dp(48), 1.2f))
        controls.addView(next, LinearLayout.LayoutParams(0, dp(48), 1f))
        nowCard.addView(controls)
        root.addView(nowCard, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        list.setOnItemClickListener { _, _, position, _ -> playAt(position) }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { filterSongs(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun controlButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 18f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFF353535.toInt())
        setOnClickListener { action() }
    }

    private fun loadSongs() {
        songs.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            contentResolver.query(collection, projection, selection, null, sort)?.use { cursor: Cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Unknown title"
                    val artist = cursor.getString(artistCol)?.takeUnless { it == "<unknown>" } ?: "Unknown artist"
                    val album = cursor.getString(albumCol) ?: "Unknown album"
                    songs.add(Song(id, title, artist, album, ContentUris.withAppendedId(collection, id)))
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't read music files", Toast.LENGTH_LONG).show()
        }
        filterSongs(search.text?.toString().orEmpty())
    }

    private fun filterSongs(query: String) {
        val q = query.trim().lowercase(Locale.getDefault())
        visibleSongs = songs.filter { it.title.lowercase(Locale.getDefault()).contains(q) || it.artist.lowercase(Locale.getDefault()).contains(q) || it.album.lowercase(Locale.getDefault()).contains(q) }
        countText.text = "YOUR SONGS  ·  ${visibleSongs.size}"
        list.adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = visibleSongs.size
            override fun getItem(position: Int) = visibleSongs[position]
            override fun getItemId(position: Int) = visibleSongs[position].id
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(9), dp(8), dp(9))
                }
                row.removeAllViews()
                val cover = TextView(this@MainActivity).apply {
                    text = "♪"
                    textSize = 23f
                    gravity = Gravity.CENTER
                    setTextColor(0xFFFF8A35.toInt())
                    setBackgroundColor(0xFF292929.toInt())
                }
                row.addView(cover, LinearLayout.LayoutParams(dp(48), dp(48)))
                val details = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
                details.addView(TextView(this@MainActivity).apply {
                    text = visibleSongs[position].title
                    textSize = 15f
                    setTextColor(0xFFFFFFFF.toInt())
                    maxLines = 1
                })
                details.addView(TextView(this@MainActivity).apply {
                    text = "${visibleSongs[position].artist}  ·  ${visibleSongs[position].album}"
                    textSize = 12f
                    setTextColor(0xFFAAAAAA.toInt())
                    maxLines = 1
                })
                row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
                return row
            }
        }
        if (songs.isEmpty()) countText.text = "YOUR SONGS  ·  No local music found"
    }

    private fun playAt(index: Int) {
        if (index !in visibleSongs.indices) return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, visibleSongs[index].uri)
                setOnCompletionListener { if (visibleSongs.isNotEmpty()) playAt((currentIndex + 1) % visibleSongs.size) }
                prepare()
                start()
            }
            currentIndex = index
            isPlaying = true
            titleNow.text = visibleSongs[index].title
            artistNow.text = visibleSongs[index].artist
            playButton.text = "Ⅱ"
        } catch (_: Exception) {
            isPlaying = false
            playButton.text = "▶"
            Toast.makeText(this, "This song couldn't be played", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) {
            if (visibleSongs.isNotEmpty()) playAt(if (currentIndex >= 0) currentIndex else 0)
            else Toast.makeText(this, "Add music files to your phone first", Toast.LENGTH_SHORT).show()
            return
        }
        if (p.isPlaying) { p.pause(); isPlaying = false; playButton.text = "▶" }
        else { p.start(); isPlaying = true; playButton.text = "Ⅱ" }
    }

    private fun hasAudioPermission() = checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED
    private fun audioPermission() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadSongs()
        else Toast.makeText(this, "Allow music access to show your songs", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
