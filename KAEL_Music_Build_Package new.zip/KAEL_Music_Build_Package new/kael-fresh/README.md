# KAEL Music

A fresh, original Android local-music-player starter project by Vivin, with a classic dark music-player layout inspired by the familiar simplicity of older phone music players. This project does not include copied S Music/SMusic branding, logos, photos, or source files.

## Current features
- Reads local audio tracks using Android's MediaStore after permission is granted
- Lists and searches songs by title, artist, or album
- Play, pause, previous, next, and automatic next-track playback
- Dark interface with original KAEL Music icon
- GitHub Actions workflow to build a debug APK

## Build APK from an Android phone
1. Create a new GitHub repository, for example `KAEL-Music`.
2. Upload the **contents** of this ZIP to the repository root (the `.github` folder must be included).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Choose **Build KAEL Music APK** and tap **Run workflow**, or push a commit.
5. Open the completed workflow run and download the `KAEL-Music-debug-APK` artifact. Extract it to get `app-debug.apk`.
6. Open the APK on your Android phone and allow installation if Android asks.

## Notes
- This is a starter build, not a full feature-for-feature clone of Samsung Music.
- Playback is currently in-app; background playback, notification/lock-screen controls, album-art extraction, playlists, equalizer, and folder browsing are not implemented yet.
- The first build may take several minutes. The APK from this workflow is a debug build and is suitable for personal testing, not Play Store release.
- Requires Android 6.0 or later. Local audio permission is requested when the app opens.
